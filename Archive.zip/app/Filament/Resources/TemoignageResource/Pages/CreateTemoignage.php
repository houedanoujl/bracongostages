<?php

namespace App\Filament\Resources\TemoignageResource\Pages;

use App\Filament\Resources\TemoignageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTemoignage extends CreateRecord
{
    protected static string $resource = TemoignageResource::class;
}
