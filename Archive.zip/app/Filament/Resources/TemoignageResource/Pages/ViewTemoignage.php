<?php

namespace App\Filament\Resources\TemoignageResource\Pages;

use App\Filament\Resources\TemoignageResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewTemoignage extends ViewRecord
{
    protected static string $resource = TemoignageResource::class;
}
