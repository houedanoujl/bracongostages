<?php

namespace App\Filament\Resources\TémoignageResource\Pages;

use App\Filament\Resources\TémoignageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTémoignage extends CreateRecord
{
    protected static string $resource = TémoignageResource::class;
}
