<?php

namespace App\Filament\Resources\OpportuniteResource\Pages;

use App\Filament\Resources\OpportuniteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOpportunite extends CreateRecord
{
    protected static string $resource = OpportuniteResource::class;
}
