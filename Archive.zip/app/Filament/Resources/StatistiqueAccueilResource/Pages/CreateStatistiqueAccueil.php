<?php

namespace App\Filament\Resources\StatistiqueAccueilResource\Pages;

use App\Filament\Resources\StatistiqueAccueilResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStatistiqueAccueil extends CreateRecord
{
    protected static string $resource = StatistiqueAccueilResource::class;
}
