<?php

namespace App\Filament\Resources\CandidatureResource\Pages;

use App\Filament\Resources\CandidatureResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCandidature extends CreateRecord
{
    protected static string $resource = CandidatureResource::class;
} 