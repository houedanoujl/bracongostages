<?php

namespace App\Filament\Resources\EtablissementPartenaireResource\Pages;

use App\Filament\Resources\EtablissementPartenaireResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEtablissementPartenaire extends CreateRecord
{
    protected static string $resource = EtablissementPartenaireResource::class;
}
